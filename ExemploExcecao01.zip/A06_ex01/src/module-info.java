/**
 * 
 */
/**
 * 
 */
module A06_ex01 {
}