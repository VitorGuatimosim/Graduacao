package a06_ex01;

public class Conta {

		String nome;
		double saldo;
		
		
	public Conta(String nome, double saldo) {
			super();
			this.nome = nome;
			this.saldo = saldo;
		}

	public void depositar(double valor) {
		if(valor < 0) {
			throw new RuntimeException("Valor inválido!");
		}
		saldo += valor;
	}
	
	public void sacar(double valor) {
		
		if(valor > saldo) {
			throw new RuntimeException("Saldo Insuficiente!");
		}
		if(valor < 0) {
			throw new RuntimeException("Valor inválido!");
		}
		saldo -= valor;
		
	}
	
	public void transferir(double valor, Conta destino) {
		this.sacar(valor);
		destino.depositar(valor);
	}
	
	public void info() {
		System.out.println("Nome: " + nome + 
				"\nSaldo: " + saldo + 
				"\n ============================================");
		
	}
}
