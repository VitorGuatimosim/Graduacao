package a06_ex01;

import java.util.Scanner;

public class Principal {
	
	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		Conta c1 = new Conta("Jonas", 5000.0);
		Conta c2 = new Conta("Vitor", 2000.0);
				
		
		try {
			c1.info();
			c1.depositar(10);
			c1.info();
			c1.sacar(800);
			c1.info();
		}catch(Exception e) {
			System.out.println("Ocorreu um erro informe outro valor!");
			System.out.println(e.getMessage());
		}finally {
			System.out.println("Fechando o programa!");
		}
		
		try {
			c1.info();
			c2.info();
			
			System.out.println("Digite um valor para transferir: ");
			double valorTransferir = entrada.nextDouble();		
			
			c1.transferir(valorTransferir, c2);
			c1.info();
			c2.info();
		}catch(Exception e) {
			System.out.println("Ocorreu um problema, informe outro valor!");
			System.out.println(e.getMessage());
		}
		
		
	}

}
