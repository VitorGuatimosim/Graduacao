package a05_ex02;

public interface Imprimivel {
	
	void imprimir();

}
