/**
 * 
 */
/**
 * 
 */
module A05_ex02 {
}