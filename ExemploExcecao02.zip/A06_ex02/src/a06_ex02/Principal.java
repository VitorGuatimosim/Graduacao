package a06_ex02;

public class Principal {
	
	public static int[] instanciaArray(int n) {
		return new int[n];
		
	}

	public static void main(String[] args) {
		int tamanho = -10;
		
		try {
			int conta = 10/0;
			int arr[] = instanciaArray(tamanho);
			
			for(int i = 0; i <tamanho;i++) {
				System.out.println(arr[i]);
			}
		
		}catch(NegativeArraySizeException e) {
			System.out.println("Valor de tamanho inválido!");
			System.out.println(e.getMessage());
			
		}catch(ArithmeticException e) {
			System.out.println("Divisão por zero");
		}
		

	}

}
