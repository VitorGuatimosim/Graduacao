/**
 * 
 */
/**
 * 
 */
module A06_ex02 {
}