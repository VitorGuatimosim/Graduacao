package a05_ex02;

public class Funcionario implements Imprimivel{
	
	String nome;
	String cpf;
	
	public Funcionario(String nome, String cpf) {
		super();
		this.nome = nome;
		this.cpf = cpf;
	}
	
	@Override
	public void imprimir() {
		System.out.println("Funcionário");
		System.out.println("Nome: " + nome 
				+ "\nCPF: " + cpf);
		System.out.println("------------------------------------");
	}
	
}
