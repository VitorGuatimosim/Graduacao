package a04_ex02;

public class Main {
	
	public static void main(String[] args) {
		IngressoVip iv = new IngressoVip("Rock in Rio", 200, 100);
		
		iv.info();

		System.out.println("---------------------------------------------");
		
		Ingresso i = new Ingresso("Lollapalooza", 50);
		i.info();
		
		
	}

}
