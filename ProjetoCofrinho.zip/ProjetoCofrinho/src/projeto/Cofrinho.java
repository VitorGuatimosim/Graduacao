package projeto;

import java.util.ArrayList;

public class Cofrinho {
	
	private ArrayList<Moeda> listaMoedas = new ArrayList();
	
	//Metódo para adicionar moedas na lista
	
	public void adicionarMoeda(Moeda m) {
		listaMoedas.add(m);		
	}
	
	//Metódo para remover moedas da lista
	
	public void removerMoeda(Moeda moeda) {
		if(listaMoedas.isEmpty()) {
			System.out.println("Cofrinho vazio!!");			
		}else {
			for(Moeda m : listaMoedas.reversed()) {
				if(m.nome == moeda.nome && m.valor == moeda.valor) {
					listaMoedas.remove(m);
					break;
				}else {
					System.out.println("Nenhum valor encontrado!");					
				}
			}
		}
	}
	
	//Metódo que mostra as moedas no cofrinho (salvas na lista)
	
	public void listagemMoedas(){
		System.out.println("Moedas no cofrinho:");
		for(Moeda m : listaMoedas) {
			m.info();			
		}
		
		//Retorna uma mensagem caso cofrinho vazio
		if(listaMoedas.isEmpty()) {
			System.out.println("Cofrinho vazio!!");
			
		}
	}
	
	//Metódo que faz a soma de todas as moedas convertidas para real e mostra o resultado
	
	public void totalConvertido(){
		double total = 0;
		for(Moeda m : listaMoedas) {
			total += m.converter();			
		}		
		System.out.println("Valor total convertido em Real: R$" + total);
	}

}
