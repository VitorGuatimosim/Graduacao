package projeto;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		
		Cofrinho cofre = new Cofrinho();
		Moeda moeda;
		Scanner entrada = new Scanner(System.in);
		Boolean continuar = true;
		int escolha;
		
		
		while(continuar) {
			System.out.println("====================== BEM VINDO AO COFRINHO ======================");
			System.out.println("1.Adicionar Moeda");
			System.out.println("2.Remover Moeda");
			System.out.println("3.Listar Moedas no cofrinho");
			System.out.println("4.Calcular total em Real");
			System.out.println("9.Sair");
			
			System.out.print("Escolha: ");
			escolha = entrada.nextInt();
			
			switch(escolha) {
			case 1:
				System.out.println("=== Adicionar Moeda ===");
				System.out.println("1.Real");
				System.out.println("2.Dolar");
				System.out.println("3.Euro");
				System.out.println("4.Voltar");
				
				System.out.print("Escolha: ");
				escolha = entrada.nextInt();
				
				switch(escolha) {
				case 1:
					System.out.print("Informe o valor do Real: R$ ");
					cofre.adicionarMoeda(new Real("REAL", entrada.nextDouble()));
					break;
				case 2:
					System.out.print("Informe o valor do Dolar:");
					cofre.adicionarMoeda(new Dolar("DOLAR", entrada.nextDouble()));
					break;
				case 3:
					System.out.print("Informe o valor do Euro: ");
					cofre.adicionarMoeda(new Euro("EURO", entrada.nextDouble()));
					break;
				case 4:
					break;
				default:
					System.out.println("Opção Inválida!! Tente Novamente!");
					break;			
				}
				break;
			case 2:
				System.out.println("=== Remover Moeda ===");
				System.out.println("1.Real");
				System.out.println("2.Dolar");
				System.out.println("3.Euro");
				System.out.println("4.Voltar");
				
				System.out.print("Escolha: ");
				escolha = entrada.nextInt();
				
				switch(escolha) {
				case 1:
					System.out.print("Informe o valor do Real que deseja remover: R$ ");
					cofre.removerMoeda(new Real("REAL", entrada.nextDouble()));
					break;
				case 2:
					System.out.print("Informe o valor do Dolar que deseja remover:");
					cofre.removerMoeda(new Dolar("DOLAR", entrada.nextDouble()));
					break;
				case 3:
					System.out.print("Informe o valor do Euro que deseja remover: ");
					cofre.removerMoeda(new Euro("EURO", entrada.nextDouble()));
					break;
				case 4:
					break;
				default:
					System.out.println("Opção Inválida!! Tente Novamente!");
					break;			
				}
				break;
			case 3:
				cofre.listagemMoedas();
				break;
			case 4:
				cofre.totalConvertido();
				break;
			case 9:
				continuar = false;
				break;
			default:
				System.out.println("Opção Inválida!! Tente Novamente!");
				break;
			}			
		}
	}
	
}
