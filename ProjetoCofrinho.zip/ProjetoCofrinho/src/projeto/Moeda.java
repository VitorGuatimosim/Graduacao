package projeto;

public abstract class Moeda {

	String nome;
	double valor;

	public Moeda(String nome, double valor) {
		super();
		this.nome = nome;
		this.valor = valor;
	}

	public abstract void info();
	
	public abstract double converter();
	
}
