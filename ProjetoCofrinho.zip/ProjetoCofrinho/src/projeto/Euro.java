package projeto;

public class Euro extends Moeda{
	
	//Construtor da classe Euro

	public Euro(String nome, double valor) {
		super(nome, valor);
	}
	
	//Metódo info que retorna os dados da classe

	@Override
	public void info() {
		System.out.println("Valor Euro: " + valor);
		
	}
	
	//Metódo que converte o valor da moeda em Real

	@Override
	public double converter() {
		return valor*10;
	}

}
