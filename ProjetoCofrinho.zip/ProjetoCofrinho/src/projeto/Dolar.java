package projeto;

public class Dolar extends Moeda{
	
	//Construtor da classe Dolar
	
	public Dolar(String nome, double valor) {
		super(nome, valor);		
	}
	
	//Metódo info que retorna os dados da classe

	@Override
	public void info() {
		System.out.println("Valor Dolar: " + valor);
		
	}
	
	//Metódo que converte o valor da moeda em Real

	@Override
	public double converter() {
		return valor*5;
		
	}

	
	
}
