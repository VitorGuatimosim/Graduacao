package projeto;

public class Real extends Moeda{
	
	//Construtor da classe Real
	
	public Real(String nome, double valor) {
		super(nome, valor);
	}

	//Metódo info que retorna os dados da classe
	
	@Override
	public void info() {
		System.out.println("Valor Real: " + valor);		
	}
	
	//Metódo que converte o valor da moeda em Real
	
	@Override
	public double converter() {
		return valor;		
	}

}
